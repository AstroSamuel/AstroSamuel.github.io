Merged JWST NIRSpec and MIRI LRS from Beiler et al. 2024b (https://iopscience.iop.org/article/10.3847/1538-4357/ad6301/pdf). 
The full reduction, marging, and calibration process can be found in Section 4. For any questions, contact Samuel Beiler.

All spectra are in .txt files with a 2 line header:
Col. 1: Wavelength (um)
Col. 2: Flux Density (Jy)
Col. 3: Flux Density Error (Jy)
Col. 4: Resolving Power

Note: WISE 2018 only has a MIRI LRS spectrum, so may need to be handled separately
